<?php
echo "Hello from test.php!";
phpinfo(); // This will display your PHP configuration
?>